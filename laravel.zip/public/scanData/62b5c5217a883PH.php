<?php
                        session_start();
                        if($_SESSION['login'] === true){
                                $UIDresult= '7.77';
                                echo $UIDresult; 
                            }
                        ?>
                    