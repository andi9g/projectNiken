<?php
                        session_start();
                        if($_SESSION['login'] === true){
                                $UIDresult= '28.50';
                                echo $UIDresult; 
                            }
                        ?>
                    