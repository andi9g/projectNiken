<?php $__env->startSection('judul'); ?>
    MONITORING
<?php $__env->stopSection(); ?>

<?php $__env->startSection('activeWelcome'); ?>
    activeku
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card-body">
        <?php $__currentLoopData = $perangkat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row mb-4">
            <div class="col-md-12 ">
                <div class="card border-bottom-0 rounded-0">
                    <h3 class="card-header rounded-0 text-center" style="background: rgb(207, 212, 221)"><?php echo e(strtoupper($p1->perangkat)); ?></h3>
                </div>
            </div>
            <div class="col-md-6 text-center mb-2">
                <div class="card rounded-0 border-top-0">
                    <div class="card-header rounded-0">PH AIR</div>
                    <div class="card-body">
                        <div class="px-md-5 py-2">
                        <div class="px-md-5 text-left">
                            <textarea name="" id="getUIDPH<?php echo e($p1->id); ?>" class="form-control disabled mb-1" cols="100" rows="1" style="resize: none" readonly></textarea>

                            <h4 class="text-dark mb-0" id="ketPH<?php echo e($p1->id); ?>">.....</h4>
                        </div>
                        </div>
                            
                    </div>
                </div>
            </div>
            <div class="col-md-6 text-center mb-2">
                <div class="card rounded-0 border-top-0">
                    <div class="card-header">SUHU AIR</div>
                    <div class="card-body">
                        <div class="px-md-5 py-2">
                        <div class="px-md-5 text-left">
                            <textarea name="" id="getUIDSUHU<?php echo e($p1->id); ?>" class="form-control mb-1" style="resize: none" cols="100" rows="1" readonly></textarea>

                            <h4 class="text-dark mb-0" id="ketSUHU<?php echo e($p1->id); ?>">.....</h4>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('myScript'); ?>
<?php $__currentLoopData = $perangkat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    

<script>

    $(document).ready(function(){
        let i = 2000;
        $("#getUIDPH<?php echo e($p2->id); ?>").load("<?php echo e(url('/scanData/'.$p2->akses.'PH.php')); ?>");
        $("#getUIDSUHU<?php echo e($p2->id); ?>").load("<?php echo e(url('/scanData/'.$p2->akses.'SUHU.php')); ?>");
        setInterval(function() {
            $("#getUIDPH<?php echo e($p2->id); ?>").load("<?php echo e(url('/scanData/'.$p2->akses.'PH.php')); ?>");
            $("#getUIDSUHU<?php echo e($p2->id); ?>").load("<?php echo e(url('/scanData/'.$p2->akses.'SUHU.php')); ?>");

            var isiPH = parseFloat(document.getElementById("getUIDPH<?php echo e($p2->id); ?>").value);
            var isiSUHU = parseFloat(document.getElementById("getUIDSUHU<?php echo e($p2->id); ?>").value);
            
            


            if(isiPH || isiPH.length > 0 && isiPH != NULL){
                if(isiPH > 6.65) {
                    document.getElementById("ketPH<?php echo e($p2->id); ?>").removeAttribute("class");
                    document.getElementById("ketPH<?php echo e($p2->id); ?>").className="text-success mb-0";
                    document.getElementById("ketPH<?php echo e($p2->id); ?>").innerHTML = "Baik";
                }else if(isiPH > 6.45) {
                    document.getElementById("ketPH<?php echo e($p2->id); ?>").removeAttribute("class");
                    document.getElementById("ketPH<?php echo e($p2->id); ?>").className="text-warning mb-0";
                    document.getElementById("ketPH<?php echo e($p2->id); ?>").innerHTML = "Kurang Baik";

                }else if(isiPH < 6.45) {
                    document.getElementById("ketPH<?php echo e($p2->id); ?>").removeAttribute("class");
                    document.getElementById("ketPH<?php echo e($p2->id); ?>").className="text-danger mb-0";
                    document.getElementById("ketPH<?php echo e($p2->id); ?>").innerHTML = "Tidak baik";
                }



                if(isiSUHU > 20.0 && isiSUHU < 29.0) {
                    document.getElementById("ketSUHU<?php echo e($p2->id); ?>").removeAttribute("class");
                    document.getElementById("ketSUHU<?php echo e($p2->id); ?>").className="text-success mb-0";

                    document.getElementById("ketSUHU<?php echo e($p2->id); ?>").innerHTML = "Baik";
                }else if(isiSUHU > 18.0 && isiSUHU < 20.0) {
                    document.getElementById("ketSUHU<?php echo e($p2->id); ?>").removeAttribute("class");
                    document.getElementById("ketSUHU<?php echo e($p2->id); ?>").className="text-warning mb-0";

                    document.getElementById("ketSUHU<?php echo e($p2->id); ?>").innerHTML = "Kurang Baik";

                }else if(isiSUHU < 18.0 || isiSUHU >= 29 ) {
                    document.getElementById("ketSUHU<?php echo e($p2->id); ?>").removeAttribute("class");
                    document.getElementById("ketSUHU<?php echo e($p2->id); ?>").className="text-danger mb-0";
                    document.getElementById("ketSUHU<?php echo e($p2->id); ?>").innerHTML = "Tidak baik";
                }


            }
            if(isNaN(isiPH) && isNaN(isiSUHU) == NaN) {
                document.getElementById("ketPH<?php echo e($p2->id); ?>").removeAttribute("class");
                document.getElementById("ketPH<?php echo e($p2->id); ?>").className="text-dark mb-0";

                document.getElementById('ketPH<?php echo e($p2->id); ?>').innerHTML = "Belum Terdaftar";
                document.getElementById('ketSUHU<?php echo e($p2->id); ?>').innerHTML = "Belum Terdaftar";
            }
            
        }, i);
    });



</script>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layoutAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/ph/resources/views/pages/pagesWelcome.blade.php ENDPATH**/ ?>