<?php $__env->startSection('judul'); ?>
    MONITORING
<?php $__env->stopSection(); ?>

<?php $__env->startSection('activePerangkat'); ?>
    activeku
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card-body">
        <h2 class="card-title text-center">Data perangkat</h2>
        
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#tambahperangkat">
            Tambah perangkat
        </button>
        <!-- Modal -->
        <div class="modal fade" id="tambahperangkat" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Data perangkat</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                </div>
                <form action="<?php echo e(route('tambah.perangkat')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                <div class="modal-body">
                        <div class="form-group">
                            <div class="form-group">
                                <label for="">Nama Perangkat</label>
                            <input type="text" name="perangkat" id="" class="form-control">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Tambah perangkat</button>
                </div>
                </form>
            </div>
            </div>
        </div>


        <div class="table-responsive mt-3">
            <table class="table table-striped table-sm table-bordered">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama perangkat</th>
                        <th>Aksi</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $perangkat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($item->perangkat); ?></td>
                            <td>
                                <button type="button" class="badge border-0 badge-info" data-toggle="modal" data-target="#detail<?php echo e($item->id); ?>">
                                    Detail
                                </button>

                                <form action="<?php echo e(route('hapus.perangkat', [$item->id])); ?>" method="post" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field("DELETE"); ?>
                                    <button type="submit" class="badge badge-danger border-0">Hapus</button>
                                </form>
                            </td>

                        </tr>


                        <div class="modal fade" id="detail<?php echo e($item->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Data perangkat</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                </div>
                                <form action="<?php echo e(route('tambah.perangkat')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                <div class="modal-body">
                                        <div class="form-group">
                                            <div class="form-group">
                                                <label for="">Key_Post</label>
                                                <textarea name="" class="form-control" readonly id="" rows="4"><?php echo e($item->key_post); ?></textarea>
                                            </div>

                                            <div class="form-group">
                                                <label for="">Kode Akses</label>
                                                <textarea name="" class="form-control" readonly id="" rows="4"><?php echo e($item->akses); ?></textarea>
                                            </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary">Tambah perangkat</button>
                                </div>
                                </form>
                            </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>

            </table>
        </div>


    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('myScript'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layoutAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/ph/resources/views/pages/pagesPerangkat.blade.php ENDPATH**/ ?>