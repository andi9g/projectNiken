<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(url('bootstrap/bootstrap.min.css', [])); ?>">
    <link rel="stylesheet" href="<?php echo e(url('bootstrap/mycss.css', [])); ?>">
    <link rel="stylesheet" href="<?php echo e(url('/css/mycss.min.css', [])); ?>">
    <title>LOGIN</title>
</head>
<body>
    
    <div class="wrapper">
        <div class="logo">
        </div>
        <div class="text-center mt-4 name">
            MONITORING 
            <h5>
                PH & Temperature
            </h5>
        </div>
        <form action="<?php echo e(route('proses.login')); ?>" method="post" class="p-3 mt-3">
            <?php echo csrf_field(); ?>
            <div class="form-field d-flex align-items-center">
                <span class="far fa-user"></span>
                <input type="text" name="username" id="userName" placeholder="Username">
            </div>
            <div class="form-field d-flex align-items-center">
                <span class="fas fa-key"></span>
                <input type="password" name="password" id="pwd" placeholder="Password">
            </div>
            <button type="submit" class="btn mt-3">Login</button>
        </form>
    </div>


    <script src="<?php echo e(url('bootstrap/jquery.slim.min.js', [])); ?>"></script>
    <script src="<?php echo e(url('bootstrap/bootstrap.bundle.min.js', [])); ?>"></script>
    <script src="<?php echo e(url('jquery.min.js', [])); ?>"></script>
    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH /opt/lampp/htdocs/ph/resources/views/pages/pagesLogin.blade.php ENDPATH**/ ?>